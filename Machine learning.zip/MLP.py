# -*- coding: utf-8 -*-
"""
Created on Wed Nov  6 17:49:26 2019

@author: Mahboobe
"""

import numpy as np

def sigmoid(x):
    return (2/(1+np.exp(-x)))-1


def y(W1,B1,X): #calculating hidden layer output
    return  sigmoid(np.dot(X, W1)+B1)  

def o(y,W2,B2): #calculating  output
    return  sigmoid(np.dot(y, W2)+ B2)



X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
D = np.array([[0], [1], [1], [0]])

epoches = 10000
lr = 0.4
inputLayerNeurons, hiddenLayerNeurons, outputLayerNeurons = 2, 2, 1

W1 = np.random.rand(inputLayerNeurons, hiddenLayerNeurons) # creating random weight matrixes
B1 = np.random.rand(1, hiddenLayerNeurons)
W2 = np.random.rand(hiddenLayerNeurons, outputLayerNeurons)
B2 = np.random.rand(1, outputLayerNeurons)



for j in range(epoches):   
    
        E = 0

        Y = y(W1,B1,X)  # hiden layer ouput
        O = o(Y,W2,B2)  #  output
        E = 0.5* np.sum((D - O)**2) # calculating cost function
        delta_o = 0.5 * (D - O)* (1- O**2) # error output layer
        delta_y = 0.5 * (1 -Y**2)* (delta_o * W2.T) # error hidden layer
        
        W2 +=lr*np.dot(Y.T ,delta_o)  # update weights
        W1 +=lr*np.dot(X.T , delta_y)

        B2 += np.sum(delta_o) * lr
        B1 += np.sum(delta_y) * lr
        
        if E < 0.01:
            print(...)
            break;
            

print(o(y(W1,B1,X),W2,B2))

