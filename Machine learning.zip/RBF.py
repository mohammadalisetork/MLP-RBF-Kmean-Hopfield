# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 12:05:15 2019

@author: user
"""
import numpy as np
import math
import sklearn.cluster as sk
from numpy.linalg import inv

def gaussian(x,mu,sig):
    d = np.sum((x - mu)**2)
    return np.exp(-np.power(d,2)*(2*np.power(sig,2)))

def find_max(c):
    size, dim = c.shape
    d = 0
    for i in range(size):
        for j in range(size):
            if d < np.sum((c[i] - c[j])**2):
                d = np.sum((c[i] - c[j])**2)
                
    return d


x = np.array([[1,1],[1, 3],[1,8],[2,1],[2,2],[2,7],[2,9],[3,1],[3, 2],[3,3],[3,6],[3,8],[4,2],[4,3],
              [4,4],[4, 8],[5,4],[5,5],[6,4],[6,7],[7,1],[7,3],[7, 4],[7,5],[7,6],[8,1],[8,2],[8,3],
              [8, 8],[8,9],[9,1],[9,2],[9,4],[9,7],[9,8],[9,9],[10,3],[10,2],[10,4],[10,10]])


C = np.array([[3,2],[8, 7],[9,3]])
size,dim = C.shape
sig = size / find_max(C)

b = np.array([[1],[1],[0],[1],[1],[0],[0],[1],[1],[1],[0],[0],[1],[1],
              [1],[0],[1],[1],[0],[1],[0],[0],[0],[0],[1],[0],[0],[0],
              [1],[1],[0],[0],[0],[1],[1],[1],[0],[0],[0],[1]])

print(b.shape)
size_inp,dim = x.shape



temp = np.zeros([1,4])
GG = np.zeros([40,4])
          
for i in range(size_inp):
    
    for j in range(3): 
        temp[0,j] = gaussian(x[i],C[j],sig)
        
    temp[0,3] = 1
    GG[i] = temp
    

#print(GG)
t = np.dot(GG.T ,GG)
w = np.dot(np.dot(inv(t),GG.T),b)
#print(w)
     
                 
                  
for j in range(3): 
    temp[0,j] = gaussian([1,9],C[j],sig)
    
temp[0,3] = 1   

o =np.dot(temp,w) 
print(o)             
                  
                  
                 