import numpy as np

import cv2



def cluster(k,maxx,dim):  #creat random center
    return np.random.rand(k,dim)*maxx


def find_cluster(C , X, k, size): # assign each point one cluster

    minn = np.zeros([size,1]);
    for j in range(size):
        dis = 1000000;
        for i in range(k):
            dis_temp = np.sum((C[i] - X[j])**2)
            if dis_temp < dis:
                dis = dis_temp
                minn[j] = i
            
    return minn;


def mean(C, X, k, X_c): #find center of  each cluster
    
    size , dim = X.shape
    summ = np.zeros([k,dim])
    for j in range(k):

        num = 0
        for i in range(size):
            if X_c[i] == j:
                summ[j] = summ[j] + X[i]
                num = num +1
        
        if num != 0 :
            summ[j] = summ[j] / num
           # print(num)
            
    return summ
    


k = 4;    #centers
maxx = 10
X= np.array([[1,1],[1.5, 2],[3,4],[5,7],[3.5,5],[4.5, 5],[3.5,4.5]])

number , dim = X.shape  #finding number of inputs and their dimension



C = cluster(k, maxx, dim)  #creat random centers
X_c = find_cluster(C , X, k, number) #assign cluster

i = 0;

while True:
    
   i += 1
   
   C = mean(C, X,k,X_c)  #update centers
   temp = X_c                   # last step clustering
   X_c = find_cluster(C , X, k, number) # new clustering
   
   if  np.allclose(temp , X_c) :  # compare last two clustering
       break
   if i == 30:
       break


print (i)   #number of update
print( C)   # final centers
print ( X_c) 



